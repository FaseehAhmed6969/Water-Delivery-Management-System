import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Droplets, Package, Clock, CheckCircle, Users, UserCog, LogOut } from 'lucide-react';
import type { Order, Customer } from '../App';

interface AdminDashboardProps {
  orders: Order[];
  customers: Customer[];
  onNavigate: (screen: string, order?: Order) => void;
  onLogout: () => void;
}

export function AdminDashboard({ orders, customers, onNavigate, onLogout }: AdminDashboardProps) {
  const pendingOrders = orders.filter(o => o.status === 'pending');
  const assignedOrders = orders.filter(o => o.status === 'assigned');
  const deliveredOrders = orders.filter(o => o.status === 'delivered');

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500';
      case 'assigned':
        return 'bg-[#1E88E5]';
      case 'delivered':
        return 'bg-[#26A69A]';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E88E5] to-[#26A69A] rounded-full flex items-center justify-center">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl">Water Filtration Plant</h1>
                <p className="text-sm text-gray-500">Admin Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm">Admin User</p>
                <p className="text-xs text-gray-500">admin@waterplant.com</p>
              </div>
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-2xl mb-2">Dashboard Overview</h2>
          <p className="text-gray-600">Manage orders, customers, and deliveries</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-[#1E88E5]/20">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 bg-[#1E88E5]/10 rounded-lg flex items-center justify-center">
                  <Package className="w-6 h-6 text-[#1E88E5]" />
                </div>
              </div>
              <CardTitle className="mt-4">{orders.length}</CardTitle>
              <CardDescription>Total Orders</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-yellow-500/20">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 bg-yellow-500/10 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
              <CardTitle className="mt-4">{pendingOrders.length}</CardTitle>
              <CardDescription>Pending Orders</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-[#26A69A]/20">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 bg-[#26A69A]/10 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-[#26A69A]" />
                </div>
              </div>
              <CardTitle className="mt-4">{deliveredOrders.length}</CardTitle>
              <CardDescription>Delivered Orders</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-gray-200">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-gray-600" />
                </div>
              </div>
              <CardTitle className="mt-4">{customers.length}</CardTitle>
              <CardDescription>Total Customers</CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow" onClick={() => onNavigate('customer-management')}>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#1E88E5]/10 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-[#1E88E5]" />
                </div>
                <div className="flex-1">
                  <CardTitle>Manage Customers</CardTitle>
                  <CardDescription>View and manage customer accounts</CardDescription>
                </div>
              </div>
            </CardHeader>
          </Card>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow border-[#26A69A]/20">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-[#26A69A]/10 rounded-lg flex items-center justify-center">
                  <UserCog className="w-6 h-6 text-[#26A69A]" />
                </div>
                <div className="flex-1">
                  <CardTitle>Assign Orders</CardTitle>
                  <CardDescription>Assign pending orders to delivery workers</CardDescription>
                </div>
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Orders</CardTitle>
            <CardDescription>Latest orders and their status</CardDescription>
          </CardHeader>
          <CardContent>
            {orders.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Package className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No orders yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {orders.slice(0, 10).map((order) => (
                  <div
                    key={order.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg hover:shadow-md transition-shadow"
                  >
                    <div className="flex-1 mb-3 sm:mb-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">#{order.id}</span>
                        <Badge className={getStatusColor(order.status)}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{order.customerName}</p>
                      <p className="text-sm text-gray-500">
                        {order.quantity}x {order.bottleSize} - {order.address}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {order.status === 'pending' && (
                        <Button
                          size="sm"
                          className="bg-[#26A69A] hover:bg-[#2E7D72]"
                          onClick={() => onNavigate('assign-order', order)}
                        >
                          Assign Worker
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onNavigate('order-tracking', order)}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
