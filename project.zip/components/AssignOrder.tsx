import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Label } from './ui/label';
import { Alert, AlertDescription } from './ui/alert';
import { ArrowLeft, Droplets, UserCog, Package, MapPin, CheckCircle } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import type { Order, Worker } from '../App';

interface AssignOrderProps {
  order: Order | null;
  workers: Worker[];
  onAssign: (orderId: string, workerName: string) => void;
  onBack: () => void;
}

export function AssignOrder({ order, workers, onAssign, onBack }: AssignOrderProps) {
  const [selectedWorker, setSelectedWorker] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <p className="text-gray-500">No order selected</p>
            <Button onClick={onBack} className="mt-4">Go Back</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleAssign = () => {
    if (!selectedWorker) {
      toast.error('Please select a delivery worker');
      return;
    }

    onAssign(order.id, selectedWorker);
    setShowSuccess(true);
    toast.success('Order assigned successfully!');
    
    setTimeout(() => {
      onBack();
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E88E5] to-[#26A69A] rounded-full flex items-center justify-center">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl">Assign Order</h1>
                <p className="text-sm text-gray-500">Assign delivery worker to order</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {showSuccess && (
          <Alert className="mb-6 border-[#26A69A] bg-[#26A69A]/10">
            <CheckCircle className="h-4 w-4 text-[#26A69A]" />
            <AlertDescription className="text-[#26A69A]">
              Order successfully assigned! Redirecting back...
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Order Details */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Order Details</CardTitle>
              <CardDescription>Order #{order.id}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <Package className="w-5 h-5 text-[#1E88E5] mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-gray-500">Order Items</p>
                  <p className="font-medium">{order.quantity}x {order.bottleSize} bottles</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <UserCog className="w-5 h-5 text-[#1E88E5] mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-gray-500">Customer</p>
                  <p className="font-medium">{order.customerName}</p>
                  <p className="text-sm text-gray-600">ID: {order.customerId}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#1E88E5] mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-gray-500">Delivery Address</p>
                  <p className="font-medium">{order.address}</p>
                </div>
              </div>

              <div className="pt-4 border-t">
                <p className="text-sm text-gray-500">Order Date</p>
                <p className="font-medium">{new Date(order.createdAt).toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>

          {/* Assignment Form */}
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle>Select Delivery Worker</CardTitle>
              <CardDescription>Choose an available worker for this order</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="worker">Delivery Worker</Label>
                <Select value={selectedWorker} onValueChange={setSelectedWorker}>
                  <SelectTrigger id="worker">
                    <SelectValue placeholder="Select a worker" />
                  </SelectTrigger>
                  <SelectContent>
                    {workers.map((worker) => (
                      <SelectItem key={worker.id} value={worker.name}>
                        <div className="flex items-center justify-between w-full">
                          <span>{worker.name}</span>
                          <span className="text-xs text-gray-500 ml-4">
                            ({worker.activeOrders} active orders)
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Worker Details */}
              {selectedWorker && (
                <div className="bg-[#26A69A]/10 p-4 rounded-lg border border-[#26A69A]/20">
                  <h3 className="font-medium mb-3 text-[#26A69A]">Worker Information</h3>
                  {workers
                    .filter(w => w.name === selectedWorker)
                    .map(worker => (
                      <div key={worker.id} className="space-y-2 text-sm">
                        <p className="flex justify-between">
                          <span className="text-gray-600">Name:</span>
                          <span className="font-medium">{worker.name}</span>
                        </p>
                        <p className="flex justify-between">
                          <span className="text-gray-600">Phone:</span>
                          <span className="font-medium">{worker.phone}</span>
                        </p>
                        <p className="flex justify-between">
                          <span className="text-gray-600">Active Orders:</span>
                          <span className="font-medium">{worker.activeOrders}</span>
                        </p>
                      </div>
                    ))}
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={onBack}
                  disabled={showSuccess}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-[#26A69A] hover:bg-[#2E7D72]"
                  onClick={handleAssign}
                  disabled={!selectedWorker || showSuccess}
                >
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Assign Worker
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
