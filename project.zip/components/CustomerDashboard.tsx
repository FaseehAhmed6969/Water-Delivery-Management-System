import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Droplets, Plus, Package, User as UserIcon, LogOut, Clock } from 'lucide-react';
import type { Order } from '../App';

interface CustomerDashboardProps {
  user: any;
  orders: Order[];
  onNavigate: (screen: string, order?: Order) => void;
  onLogout: () => void;
}

export function CustomerDashboard({ user, orders, onNavigate, onLogout }: CustomerDashboardProps) {
  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500';
      case 'assigned':
        return 'bg-[#1E88E5]';
      case 'delivered':
        return 'bg-[#26A69A]';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusLabel = (status: Order['status']) => {
    return status.charAt(0).toUpperCase() + status.slice(1);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E88E5] to-[#26A69A] rounded-full flex items-center justify-center">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl">Water Filtration Plant</h1>
                <p className="text-sm text-gray-500">Customer Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm">{user?.name}</p>
                <p className="text-xs text-gray-500">{user?.email}</p>
              </div>
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-2xl mb-2">Welcome back, {user?.name?.split(' ')[0]}!</h2>
          <p className="text-gray-600">Manage your water bottle orders</p>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="cursor-pointer hover:shadow-lg transition-shadow border-[#1E88E5]/20" onClick={() => onNavigate('new-order')}>
            <CardHeader>
              <div className="w-12 h-12 bg-[#1E88E5]/10 rounded-lg flex items-center justify-center mb-3">
                <Plus className="w-6 h-6 text-[#1E88E5]" />
              </div>
              <CardTitle>New Order</CardTitle>
              <CardDescription>Place a new water bottle order</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-[#26A69A]/20">
            <CardHeader>
              <div className="w-12 h-12 bg-[#26A69A]/10 rounded-lg flex items-center justify-center mb-3">
                <Package className="w-6 h-6 text-[#26A69A]" />
              </div>
              <CardTitle>{orders.length}</CardTitle>
              <CardDescription>Total Orders</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-gray-200">
            <CardHeader>
              <div className="w-12 h-12 bg-yellow-500/10 rounded-lg flex items-center justify-center mb-3">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
              <CardTitle>{orders.filter(o => o.status === 'pending' || o.status === 'assigned').length}</CardTitle>
              <CardDescription>Active Orders</CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* My Orders */}
        <Card>
          <CardHeader>
            <CardTitle>My Orders</CardTitle>
            <CardDescription>View and track your order history</CardDescription>
          </CardHeader>
          <CardContent>
            {orders.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Package className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No orders yet</p>
                <Button 
                  className="mt-4 bg-[#1E88E5] hover:bg-[#1976D2]"
                  onClick={() => onNavigate('new-order')}
                >
                  Place Your First Order
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map((order) => (
                  <div
                    key={order.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border rounded-lg hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => onNavigate('order-tracking', order)}
                  >
                    <div className="flex-1 mb-3 sm:mb-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">Order #{order.id}</span>
                        <Badge className={getStatusColor(order.status)}>
                          {getStatusLabel(order.status)}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">
                        {order.quantity}x {order.bottleSize} bottles
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(order.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <Button variant="outline" size="sm">
                      Track Order
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Profile Section */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <UserIcon className="w-5 h-5" />
              Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-sm text-gray-500">Name</p>
              <p>{user?.name}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Email</p>
              <p>{user?.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Customer ID</p>
              <p>{user?.id}</p>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
