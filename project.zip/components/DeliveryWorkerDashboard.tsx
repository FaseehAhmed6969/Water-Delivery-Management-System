import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Droplets, Package, Truck, CheckCircle, MapPin, User, LogOut } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import type { Order } from '../App';

interface DeliveryWorkerDashboardProps {
  user: any;
  orders: Order[];
  onUpdateStatus: (orderId: string, status: Order['status']) => void;
  onLogout: () => void;
}

export function DeliveryWorkerDashboard({ user, orders, onUpdateStatus, onLogout }: DeliveryWorkerDashboardProps) {
  const assignedOrders = orders.filter(o => o.status === 'assigned');
  const deliveredOrders = orders.filter(o => o.status === 'delivered');

  const handleStatusToggle = (order: Order, checked: boolean) => {
    if (checked) {
      onUpdateStatus(order.id, 'delivered');
      toast.success(`Order ${order.id} marked as delivered!`);
    } else {
      onUpdateStatus(order.id, 'assigned');
      toast.info(`Order ${order.id} status updated`);
    }
  };

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'assigned':
        return 'bg-[#1E88E5]';
      case 'delivered':
        return 'bg-[#26A69A]';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E88E5] to-[#26A69A] rounded-full flex items-center justify-center">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl">Water Filtration Plant</h1>
                <p className="text-sm text-gray-500">Delivery Worker Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-sm">{user?.name}</p>
                <p className="text-xs text-gray-500">{user?.email}</p>
              </div>
              <Button variant="outline" size="sm" onClick={onLogout}>
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h2 className="text-2xl mb-2">Welcome, {user?.name?.split(' ')[0]}!</h2>
          <p className="text-gray-600">Manage your assigned deliveries</p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="border-[#1E88E5]/20">
            <CardHeader>
              <div className="w-12 h-12 bg-[#1E88E5]/10 rounded-lg flex items-center justify-center mb-3">
                <Package className="w-6 h-6 text-[#1E88E5]" />
              </div>
              <CardTitle>{orders.length}</CardTitle>
              <CardDescription>Total Assigned Orders</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-yellow-500/20">
            <CardHeader>
              <div className="w-12 h-12 bg-yellow-500/10 rounded-lg flex items-center justify-center mb-3">
                <Truck className="w-6 h-6 text-yellow-600" />
              </div>
              <CardTitle>{assignedOrders.length}</CardTitle>
              <CardDescription>Pending Deliveries</CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-[#26A69A]/20">
            <CardHeader>
              <div className="w-12 h-12 bg-[#26A69A]/10 rounded-lg flex items-center justify-center mb-3">
                <CheckCircle className="w-6 h-6 text-[#26A69A]" />
              </div>
              <CardTitle>{deliveredOrders.length}</CardTitle>
              <CardDescription>Completed Deliveries</CardDescription>
            </CardHeader>
          </Card>
        </div>

        {/* Assigned Orders Table */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>My Assigned Orders</CardTitle>
            <CardDescription>View and update delivery status</CardDescription>
          </CardHeader>
          <CardContent>
            {orders.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Package className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No orders assigned yet</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Order ID</TableHead>
                      <TableHead>Customer</TableHead>
                      <TableHead className="hidden md:table-cell">Items</TableHead>
                      <TableHead className="hidden lg:table-cell">Address</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Mark Delivered</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.id}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-gray-400" />
                            <div>
                              <p>{order.customerName}</p>
                              <p className="text-xs text-gray-500">{order.customerId}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <div className="flex items-center gap-2">
                            <Package className="w-4 h-4 text-gray-400" />
                            {order.quantity}x {order.bottleSize}
                          </div>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          <div className="flex items-center gap-2">
                            <MapPin className="w-4 h-4 text-gray-400" />
                            <span className="max-w-xs truncate">{order.address}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(order.status)}>
                            {order.status === 'assigned' ? 'Out for Delivery' : 'Delivered'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Switch
                              checked={order.status === 'delivered'}
                              onCheckedChange={(checked) => handleStatusToggle(order, checked)}
                              className="data-[state=checked]:bg-[#26A69A]"
                            />
                            {order.status === 'delivered' && (
                              <CheckCircle className="w-4 h-4 text-[#26A69A]" />
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-[#1E88E5]" />
                Today's Deliveries
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {assignedOrders.slice(0, 3).map(order => (
                  <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{order.customerName}</p>
                      <p className="text-xs text-gray-500">{order.quantity}x {order.bottleSize}</p>
                    </div>
                    <Badge variant="outline" className="text-xs">Pending</Badge>
                  </div>
                ))}
                {assignedOrders.length === 0 && (
                  <p className="text-sm text-gray-500 text-center py-4">All deliveries completed!</p>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="border-[#26A69A]/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-[#26A69A]" />
                Completed Today
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {deliveredOrders.slice(0, 3).map(order => (
                  <div key={order.id} className="flex items-center justify-between p-3 bg-[#26A69A]/5 rounded-lg border border-[#26A69A]/20">
                    <div>
                      <p className="font-medium text-sm">{order.customerName}</p>
                      <p className="text-xs text-gray-500">{order.quantity}x {order.bottleSize}</p>
                    </div>
                    <CheckCircle className="w-4 h-4 text-[#26A69A]" />
                  </div>
                ))}
                {deliveredOrders.length === 0 && (
                  <p className="text-sm text-gray-500 text-center py-4">No completed deliveries yet</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
