import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { Separator } from './ui/separator';
import { 
  Droplets, 
  Package, 
  Users, 
  CheckCircle, 
  Clock, 
  Truck,
  AlertCircle,
  Info,
  XCircle
} from 'lucide-react';

/**
 * Design System Showcase Component
 * 
 * This component demonstrates all design system tokens, colors, typography,
 * and components following the Water Filtration Plant design system.
 * 
 * Use this as a reference for implementing consistent UI across the application.
 */

export function DesignSystemShowcase() {
  return (
    <div className="min-h-screen bg-[#F5F7FA] p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-gradient-to-br from-[#1E88E5] to-[#26A69A] rounded-full flex items-center justify-center">
              <Droplets className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-[32px] font-semibold text-[#37474F]">
            Water Filtration Plant Design System
          </h1>
          <p className="text-[16px] text-[#607D8B]">
            Comprehensive style guide and component library
          </p>
        </div>

        {/* Color Palette */}
        <Card>
          <CardHeader>
            <CardTitle>Color Palette</CardTitle>
            <CardDescription>Primary, secondary, neutral, and status colors</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* Primary Colors */}
            <div>
              <h3 className="text-[20px] font-medium mb-4 text-[#37474F]">Primary Colors</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <div className="h-24 bg-[#1E88E5] rounded-lg shadow-md flex items-center justify-center">
                    <span className="text-white font-medium">Primary Blue</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#1E88E5</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 bg-[#1976D2] rounded-lg shadow-md flex items-center justify-center">
                    <span className="text-white font-medium">Blue Hover</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#1976D2</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 bg-[#E3F2FD] rounded-lg shadow-md flex items-center justify-center border border-[#E0E0E0]">
                    <span className="text-[#1976D2] font-medium">Blue Light</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#E3F2FD</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Secondary Colors */}
            <div>
              <h3 className="text-[20px] font-medium mb-4 text-[#37474F]">Secondary Colors</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <div className="h-24 bg-[#26A69A] rounded-lg shadow-md flex items-center justify-center">
                    <span className="text-white font-medium">Secondary Teal</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#26A69A</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 bg-[#2E7D72] rounded-lg shadow-md flex items-center justify-center">
                    <span className="text-white font-medium">Teal Hover</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#2E7D72</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 bg-[#E0F2F1] rounded-lg shadow-md flex items-center justify-center border border-[#E0E0E0]">
                    <span className="text-[#2E7D72] font-medium">Teal Light</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#E0F2F1</p>
                </div>
              </div>
            </div>

            <Separator />

            {/* Status Colors */}
            <div>
              <h3 className="text-[20px] font-medium mb-4 text-[#37474F]">Status Colors</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <div className="h-24 bg-[#43A047] rounded-lg shadow-md flex items-center justify-center">
                    <span className="text-white font-medium">Success</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#43A047</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 bg-[#E53935] rounded-lg shadow-md flex items-center justify-center">
                    <span className="text-white font-medium">Error</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#E53935</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 bg-[#FFCA28] rounded-lg shadow-md flex items-center justify-center">
                    <span className="text-[#F57F17] font-medium">Warning</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#FFCA28</p>
                </div>
                <div className="space-y-2">
                  <div className="h-24 bg-[#F5F7FA] rounded-lg shadow-md flex items-center justify-center border border-[#E0E0E0]">
                    <span className="text-[#607D8B] font-medium">Light Gray</span>
                  </div>
                  <p className="text-sm text-[#607D8B]">#F5F7FA</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Typography */}
        <Card>
          <CardHeader>
            <CardTitle>Typography Scale</CardTitle>
            <CardDescription>Font sizes and weights using Inter font family</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-[#607D8B] mb-2">H1 - 32px / Semi-Bold</p>
                <h1 className="text-[32px] font-semibold text-[#37474F]">
                  Page Title Heading
                </h1>
              </div>
              
              <div>
                <p className="text-sm text-[#607D8B] mb-2">H2 - 24px / Medium</p>
                <h2 className="text-[24px] font-medium text-[#37474F]">
                  Section Header
                </h2>
              </div>
              
              <div>
                <p className="text-sm text-[#607D8B] mb-2">H3 - 20px / Medium</p>
                <h3 className="text-[20px] font-medium text-[#37474F]">
                  Subsection Header
                </h3>
              </div>
              
              <div>
                <p className="text-sm text-[#607D8B] mb-2">Body - 16px / Regular</p>
                <p className="text-[16px] font-normal text-[#37474F]">
                  This is body text used for paragraphs, labels, and general content throughout the application.
                </p>
              </div>
              
              <div>
                <p className="text-sm text-[#607D8B] mb-2">Small Text - 14px / Regular</p>
                <p className="text-[14px] font-normal text-[#607D8B]">
                  Helper text, table cells, and secondary information
                </p>
              </div>
              
              <div>
                <p className="text-sm text-[#607D8B] mb-2">Caption - 12px / Regular</p>
                <p className="text-[12px] font-normal text-[#607D8B]">
                  Metadata, timestamps, and fine print
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Buttons */}
        <Card>
          <CardHeader>
            <CardTitle>Button Variants</CardTitle>
            <CardDescription>Primary, secondary, outline, and state variations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-wrap gap-4">
              <Button className="bg-[#1E88E5] hover:bg-[#1976D2]">
                Primary Button
              </Button>
              <Button className="bg-[#26A69A] hover:bg-[#2E7D72]">
                Secondary Button
              </Button>
              <Button variant="outline">
                Outline Button
              </Button>
              <Button variant="ghost">
                Ghost Button
              </Button>
              <Button disabled className="opacity-60">
                Disabled Button
              </Button>
            </div>

            <Separator />

            <div className="flex flex-wrap gap-4">
              <Button size="sm" className="bg-[#1E88E5] hover:bg-[#1976D2]">
                Small Button
              </Button>
              <Button size="default" className="bg-[#1E88E5] hover:bg-[#1976D2]">
                Default Button
              </Button>
              <Button size="lg" className="bg-[#1E88E5] hover:bg-[#1976D2]">
                Large Button
              </Button>
            </div>

            <Separator />

            <div className="flex flex-wrap gap-4">
              <Button className="bg-[#1E88E5] hover:bg-[#1976D2]">
                <Package className="w-4 h-4 mr-2" />
                With Icon
              </Button>
              <Button className="bg-[#26A69A] hover:bg-[#2E7D72]">
                <CheckCircle className="w-4 h-4 mr-2" />
                Confirm Order
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Badges */}
        <Card>
          <CardHeader>
            <CardTitle>Status Badges</CardTitle>
            <CardDescription>Order status and notification badges</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Badge className="bg-[#FFCA28] text-[#F57F17] border-[#FFCA28]">
                <Clock className="w-3 h-3 mr-1" />
                Pending
              </Badge>
              <Badge className="bg-[#1E88E5] text-white">
                <Truck className="w-3 h-3 mr-1" />
                Assigned
              </Badge>
              <Badge className="bg-[#43A047] text-white">
                <CheckCircle className="w-3 h-3 mr-1" />
                Delivered
              </Badge>
              <Badge variant="outline" className="border-[#E0E0E0]">
                Default
              </Badge>
              <Badge variant="secondary">
                Secondary
              </Badge>
              <Badge className="bg-[#E53935] text-white">
                <XCircle className="w-3 h-3 mr-1" />
                Cancelled
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Form Inputs */}
        <Card>
          <CardHeader>
            <CardTitle>Form Inputs</CardTitle>
            <CardDescription>Text inputs, selects, and form elements</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="text">Text Input</Label>
                <Input 
                  id="text" 
                  type="text" 
                  placeholder="Enter text..."
                  className="border-[#E0E0E0]"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email Input</Label>
                <Input 
                  id="email" 
                  type="email" 
                  placeholder="customer@email.com"
                  className="border-[#E0E0E0]"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="password">Password Input</Label>
                <Input 
                  id="password" 
                  type="password" 
                  placeholder="••••••••"
                  className="border-[#E0E0E0]"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="disabled">Disabled Input</Label>
                <Input 
                  id="disabled" 
                  type="text" 
                  placeholder="Disabled"
                  disabled
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Alert Messages */}
        <Card>
          <CardHeader>
            <CardTitle>Alert Messages</CardTitle>
            <CardDescription>Success, error, warning, and info alerts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert className="border-[#43A047] bg-[#E8F5E9]">
              <CheckCircle className="h-4 w-4 text-[#43A047]" />
              <AlertDescription className="text-[#43A047]">
                Order successfully delivered!
              </AlertDescription>
            </Alert>

            <Alert className="border-[#E53935] bg-[#FFEBEE]">
              <XCircle className="h-4 w-4 text-[#E53935]" />
              <AlertDescription className="text-[#E53935]">
                Failed to process order. Please try again.
              </AlertDescription>
            </Alert>

            <Alert className="border-[#FFCA28] bg-[#FFF9E6]">
              <AlertCircle className="h-4 w-4 text-[#F57F17]" />
              <AlertDescription className="text-[#F57F17]">
                Order is pending assignment to delivery worker.
              </AlertDescription>
            </Alert>

            <Alert className="border-[#1E88E5] bg-[#E3F2FD]">
              <Info className="h-4 w-4 text-[#1E88E5]" />
              <AlertDescription className="text-[#1E88E5]">
                Your order has been assigned to a delivery worker.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {/* Dashboard Cards */}
        <Card>
          <CardHeader>
            <CardTitle>Dashboard Stat Cards</CardTitle>
            <CardDescription>Metric cards with icons and color coding</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-[#1E88E5]/20">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#1E88E5]/10 rounded-lg flex items-center justify-center mb-3">
                    <Package className="w-6 h-6 text-[#1E88E5]" />
                  </div>
                  <CardTitle>125</CardTitle>
                  <CardDescription>Total Orders</CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-[#FFCA28]/20">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#FFCA28]/10 rounded-lg flex items-center justify-center mb-3">
                    <Clock className="w-6 h-6 text-[#F57F17]" />
                  </div>
                  <CardTitle>24</CardTitle>
                  <CardDescription>Pending Orders</CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-[#43A047]/20">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#43A047]/10 rounded-lg flex items-center justify-center mb-3">
                    <CheckCircle className="w-6 h-6 text-[#43A047]" />
                  </div>
                  <CardTitle>89</CardTitle>
                  <CardDescription>Delivered</CardDescription>
                </CardHeader>
              </Card>

              <Card className="border-[#26A69A]/20">
                <CardHeader>
                  <div className="w-12 h-12 bg-[#26A69A]/10 rounded-lg flex items-center justify-center mb-3">
                    <Users className="w-6 h-6 text-[#26A69A]" />
                  </div>
                  <CardTitle>342</CardTitle>
                  <CardDescription>Customers</CardDescription>
                </CardHeader>
              </Card>
            </div>
          </CardContent>
        </Card>

        {/* Spacing Reference */}
        <Card>
          <CardHeader>
            <CardTitle>Spacing System (8px Grid)</CardTitle>
            <CardDescription>Standardized spacing tokens</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {[
                { label: 'spacing-1', value: '4px', class: 'w-1' },
                { label: 'spacing-2', value: '8px', class: 'w-2' },
                { label: 'spacing-3', value: '12px', class: 'w-3' },
                { label: 'spacing-4', value: '16px', class: 'w-4' },
                { label: 'spacing-6', value: '24px', class: 'w-6' },
                { label: 'spacing-8', value: '32px', class: 'w-8' },
                { label: 'spacing-12', value: '48px', class: 'w-12' },
              ].map(({ label, value, class: className }) => (
                <div key={label} className="flex items-center gap-4">
                  <div className="w-32 text-sm text-[#607D8B]">{label} - {value}</div>
                  <div className={`h-8 ${className} bg-[#1E88E5] rounded`}></div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Border Radius */}
        <Card>
          <CardHeader>
            <CardTitle>Border Radius</CardTitle>
            <CardDescription>Rounded corner variations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="text-center space-y-2">
                <div className="h-20 bg-[#1E88E5] rounded" />
                <p className="text-sm text-[#607D8B]">None (0px)</p>
              </div>
              <div className="text-center space-y-2">
                <div className="h-20 bg-[#1E88E5] rounded-sm" />
                <p className="text-sm text-[#607D8B]">Small (4px)</p>
              </div>
              <div className="text-center space-y-2">
                <div className="h-20 bg-[#1E88E5] rounded-md" />
                <p className="text-sm text-[#607D8B]">Medium (8px)</p>
              </div>
              <div className="text-center space-y-2">
                <div className="h-20 bg-[#1E88E5] rounded-lg" />
                <p className="text-sm text-[#607D8B]">Large (12px)</p>
              </div>
              <div className="text-center space-y-2">
                <div className="h-20 bg-[#1E88E5] rounded-full" />
                <p className="text-sm text-[#607D8B]">Full (pill)</p>
              </div>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
