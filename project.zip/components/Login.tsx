import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Droplets, User, Lock } from 'lucide-react';
import type { UserRole } from '../App';

interface LoginProps {
  onLogin: (role: UserRole, userData: any) => void;
}

export function Login({ onLogin }: LoginProps) {
  const [isRegister, setIsRegister] = useState(false);
  const [activeTab, setActiveTab] = useState<'customer' | 'admin' | 'worker'>('customer');

  const handleSubmit = (e: React.FormEvent, role: UserRole) => {
    e.preventDefault();
    
    // Mock user data based on role
    const userData = {
      customer: { id: 'CUST001', name: 'John Smith', email: 'john.smith@email.com' },
      admin: { id: 'ADM001', name: 'Admin User', email: 'admin@waterplant.com' },
      worker: { id: 'WRK001', name: 'Mike Wilson', email: 'mike.wilson@waterplant.com' }
    };

    onLogin(role, userData[role as keyof typeof userData]);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#1E88E5]/10 to-[#26A69A]/10 p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-gradient-to-br from-[#1E88E5] to-[#26A69A] rounded-full flex items-center justify-center">
              <Droplets className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl">Water Filtration Plant</CardTitle>
          <CardDescription>
            {isRegister ? 'Create your account' : 'Sign in to your account'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="customer">Customer</TabsTrigger>
              <TabsTrigger value="admin">Admin</TabsTrigger>
              <TabsTrigger value="worker">Worker</TabsTrigger>
            </TabsList>

            <TabsContent value="customer" className="space-y-4 mt-6">
              <form onSubmit={(e) => handleSubmit(e, 'customer')} className="space-y-4">
                {isRegister && (
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <div className="relative">
                      <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                      <Input id="name" placeholder="John Smith" className="pl-10" />
                    </div>
                  </div>
                )}
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input id="email" type="email" placeholder="customer@email.com" className="pl-10" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input id="password" type="password" placeholder="••••••••" className="pl-10" />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-[#1E88E5] hover:bg-[#1976D2]">
                  {isRegister ? 'Register' : 'Sign In'}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="admin" className="space-y-4 mt-6">
              <form onSubmit={(e) => handleSubmit(e, 'admin')} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="admin-email">Admin Email</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input id="admin-email" type="email" placeholder="admin@waterplant.com" className="pl-10" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input id="admin-password" type="password" placeholder="••••••••" className="pl-10" />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-[#1E88E5] hover:bg-[#1976D2]">
                  Sign In as Admin
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="worker" className="space-y-4 mt-6">
              <form onSubmit={(e) => handleSubmit(e, 'worker')} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="worker-email">Worker Email</Label>
                  <div className="relative">
                    <User className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input id="worker-email" type="email" placeholder="worker@waterplant.com" className="pl-10" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="worker-password">Password</Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input id="worker-password" type="password" placeholder="••••••••" className="pl-10" />
                  </div>
                </div>
                <Button type="submit" className="w-full bg-[#26A69A] hover:bg-[#2E7D72]">
                  Sign In as Worker
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          <div className="mt-4 text-center text-sm">
            {isRegister ? (
              <>
                Already have an account?{' '}
                <button
                  onClick={() => setIsRegister(false)}
                  className="text-[#1E88E5] hover:underline"
                >
                  Sign in
                </button>
              </>
            ) : (
              <>
                Don't have an account?{' '}
                <button
                  onClick={() => setIsRegister(true)}
                  className="text-[#1E88E5] hover:underline"
                >
                  Register
                </button>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
