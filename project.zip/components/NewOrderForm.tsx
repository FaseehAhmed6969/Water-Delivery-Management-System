import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { ArrowLeft, Droplets, Package, MapPin, Hash } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

interface NewOrderFormProps {
  user: any;
  onSubmit: (order: any) => void;
  onBack: () => void;
}

export function NewOrderForm({ user, onSubmit, onBack }: NewOrderFormProps) {
  const [bottleSize, setBottleSize] = useState('');
  const [quantity, setQuantity] = useState('');
  const [address, setAddress] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!bottleSize || !quantity || !address) {
      toast.error('Please fill in all fields');
      return;
    }

    const order = {
      customerId: user.id,
      customerName: user.name,
      bottleSize,
      quantity: parseInt(quantity),
      address
    };

    onSubmit(order);
    toast.success('Order placed successfully!');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E88E5] to-[#26A69A] rounded-full flex items-center justify-center">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl">New Order</h1>
                <p className="text-sm text-gray-500">Place your water bottle order</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Order Details</CardTitle>
            <CardDescription>Fill in the details for your water bottle delivery</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Bottle Size */}
              <div className="space-y-2">
                <Label htmlFor="bottleSize" className="flex items-center gap-2">
                  <Package className="w-4 h-4 text-[#1E88E5]" />
                  Bottle Size
                </Label>
                <Select value={bottleSize} onValueChange={setBottleSize}>
                  <SelectTrigger id="bottleSize">
                    <SelectValue placeholder="Select bottle size" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="5L">5 Liters</SelectItem>
                    <SelectItem value="10L">10 Liters</SelectItem>
                    <SelectItem value="20L">20 Liters</SelectItem>
                    <SelectItem value="25L">25 Liters</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Quantity */}
              <div className="space-y-2">
                <Label htmlFor="quantity" className="flex items-center gap-2">
                  <Hash className="w-4 h-4 text-[#1E88E5]" />
                  Quantity
                </Label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  max="100"
                  placeholder="Enter number of bottles"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                />
                <p className="text-xs text-gray-500">Maximum 100 bottles per order</p>
              </div>

              {/* Delivery Address */}
              <div className="space-y-2">
                <Label htmlFor="address" className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#1E88E5]" />
                  Delivery Address
                </Label>
                <Textarea
                  id="address"
                  placeholder="Enter complete delivery address"
                  rows={3}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                />
              </div>

              {/* Order Summary */}
              {bottleSize && quantity && (
                <div className="bg-[#1E88E5]/5 p-4 rounded-lg border border-[#1E88E5]/20">
                  <h3 className="font-medium mb-2">Order Summary</h3>
                  <div className="space-y-1 text-sm">
                    <p className="flex justify-between">
                      <span className="text-gray-600">Bottle Size:</span>
                      <span>{bottleSize}</span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-gray-600">Quantity:</span>
                      <span>{quantity} bottles</span>
                    </p>
                    <p className="flex justify-between">
                      <span className="text-gray-600">Customer:</span>
                      <span>{user?.name}</span>
                    </p>
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={onBack}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="flex-1 bg-[#1E88E5] hover:bg-[#1976D2]"
                >
                  Confirm Order
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
