import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ArrowLeft, Droplets, Package, Clock, Truck, CheckCircle, MapPin, User } from 'lucide-react';
import type { Order } from '../App';

interface OrderTrackingProps {
  order: Order | null;
  onBack: () => void;
}

export function OrderTracking({ order, onBack }: OrderTrackingProps) {
  if (!order) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="p-8 text-center">
            <p className="text-gray-500">No order selected</p>
            <Button onClick={onBack} className="mt-4">Go Back</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getProgressValue = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 33;
      case 'assigned':
        return 66;
      case 'delivered':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-500';
      case 'assigned':
        return 'bg-[#1E88E5]';
      case 'delivered':
        return 'bg-[#26A69A]';
      default:
        return 'bg-gray-500';
    }
  };

  const steps = [
    { 
      status: 'pending', 
      label: 'Order Placed', 
      icon: Clock,
      description: 'Your order has been received'
    },
    { 
      status: 'assigned', 
      label: 'Out for Delivery', 
      icon: Truck,
      description: 'Delivery worker assigned'
    },
    { 
      status: 'delivered', 
      label: 'Delivered', 
      icon: CheckCircle,
      description: 'Order completed successfully'
    }
  ];

  const currentStepIndex = steps.findIndex(step => step.status === order.status);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-4xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#1E88E5] to-[#26A69A] rounded-full flex items-center justify-center">
                <Droplets className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl">Track Order</h1>
                <p className="text-sm text-gray-500">Order #{order.id}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
        {/* Status Card */}
        <Card className="mb-6 shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Order Status</CardTitle>
              <Badge className={getStatusColor(order.status)}>
                {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {/* Progress Bar */}
            <div className="mb-8">
              <Progress value={getProgressValue(order.status)} className="h-2" />
            </div>

            {/* Status Steps */}
            <div className="space-y-6">
              {steps.map((step, index) => {
                const StepIcon = step.icon;
                const isCompleted = index <= currentStepIndex;
                const isCurrent = index === currentStepIndex;

                return (
                  <div key={step.status} className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                      isCompleted 
                        ? 'bg-[#26A69A] text-white' 
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      <StepIcon className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <h3 className={`font-medium ${isCompleted ? 'text-gray-900' : 'text-gray-400'}`}>
                        {step.label}
                      </h3>
                      <p className={`text-sm ${isCompleted ? 'text-gray-600' : 'text-gray-400'}`}>
                        {step.description}
                      </p>
                      {isCurrent && order.assignedTo && (
                        <div className="mt-2 flex items-center gap-2 text-sm text-[#1E88E5]">
                          <User className="w-4 h-4" />
                          <span>Assigned to: {order.assignedTo}</span>
                        </div>
                      )}
                    </div>
                    {isCompleted && (
                      <CheckCircle className="w-5 h-5 text-[#26A69A]" />
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Order Details */}
        <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Order Details</CardTitle>
            <CardDescription>Information about your order</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <Package className="w-5 h-5 text-[#1E88E5] mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500">Order Items</p>
                    <p className="font-medium">{order.quantity}x {order.bottleSize} bottles</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <User className="w-5 h-5 text-[#1E88E5] mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500">Customer</p>
                    <p className="font-medium">{order.customerName}</p>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#1E88E5] mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500">Delivery Address</p>
                    <p className="font-medium">{order.address}</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-[#1E88E5] mt-0.5" />
                  <div>
                    <p className="text-sm text-gray-500">Order Date</p>
                    <p className="font-medium">{new Date(order.createdAt).toLocaleString()}</p>
                  </div>
                </div>
              </div>
            </div>

            {order.status === 'delivered' && (
              <div className="mt-6 p-4 bg-[#26A69A]/10 border border-[#26A69A]/20 rounded-lg">
                <div className="flex items-center gap-2 text-[#26A69A]">
                  <CheckCircle className="w-5 h-5" />
                  <p className="font-medium">Order Delivered Successfully!</p>
                </div>
                <p className="text-sm text-gray-600 mt-1">Thank you for your order!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
